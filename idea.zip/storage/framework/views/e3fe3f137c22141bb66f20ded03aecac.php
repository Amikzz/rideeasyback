<?php if (isset($component)) { $__componentOriginal9ac128a9029c0e4701924bd2d73d7f54 = $component; } ?>
<?php if (isset($attributes)) { $__attributesOriginal9ac128a9029c0e4701924bd2d73d7f54 = $attributes; } ?>
<?php $component = App\View\Components\AppLayout::resolve([] + (isset($attributes) && $attributes instanceof Illuminate\View\ComponentAttributeBag ? $attributes->all() : [])); ?>
<?php $component->withName('app-layout'); ?>
<?php if ($component->shouldRender()): ?>
<?php $__env->startComponent($component->resolveView(), $component->data()); ?>
<?php if (isset($attributes) && $attributes instanceof Illuminate\View\ComponentAttributeBag): ?>
<?php $attributes = $attributes->except(\App\View\Components\AppLayout::ignoredParameterNames()); ?>
<?php endif; ?>
<?php $component->withAttributes([]); ?>
     <?php $__env->slot('header', null, []); ?> 
        <h2 class="font-semibold text-xl text-gray-800 leading-tight">
            <?php echo e(__('Dashboard')); ?>

        </h2>
     <?php $__env->endSlot(); ?>

    <div class="py-12">
        <div class="max-w-7xl mx-auto sm:px-6 lg:px-8">
            <div class="bg-white overflow-hidden shadow-xl sm:rounded-lg">
                <div class="p-6 sm:px-20 bg-white border-b border-gray-200">
                    <div class="mt-8 text-2xl">
                        Welcome to your RideEasy Portal!
                    </div>

                    <div class="mt-6 text-gray-500">
                        You're logged in! You can now view your rides, add new rides, and view your profile.
                    </div>
                </div>

                <!-- Add the buttons here -->
                <div class="p-6 sm:px-20 bg-white border-b border-gray-200">
                    <div class="mt-6 grid grid-cols-1 md:grid-cols-2 lg:grid-cols-4 gap-4">
                        <a href="<?php echo e(route('viewtrips')); ?>" class="block text-center bg-blue-500 hover:bg-blue-700 text-white font-bold py-2 px-4 rounded-lg transition duration-300 ease-in-out">
                            View Trips
                        </a>
                        <a href="<?php echo e(route('addride')); ?>" class="block text-center bg-green-500 hover:bg-green-700 text-white font-bold py-2 px-4 rounded-lg transition duration-300 ease-in-out">
                            Add New Trip Day
                        </a>
                        <a href="" class="block text-center bg-yellow-500 hover:bg-yellow-700 text-white font-bold py-2 px-4 rounded-lg transition duration-300 ease-in-out">
                            Tickets
                        </a>
                        <a href="<?php echo e(route('deleteride')); ?>" class="block text-center bg-red-500 hover:bg-red-700 text-white font-bold py-2 px-4 rounded-lg transition duration-300 ease-in-out">
                            Cancel Rides
                        </a>
                    </div>
                </div>

                <!-- Add form for bus license plate number -->
                <div class="p-6 sm:px-20 bg-white border-b border-gray-200" id="bus-form">
                    <form id="bus-license-form">
                        <?php echo csrf_field(); ?>
                        <label for="bus_license">Enter Bus License Plate Number:</label>
                        <input type="text" id="bus_license" name="bus_license" required class="block mt-1 w-full">
                        <button type="submit" class="mt-2 bg-blue-500 hover:bg-blue-700 text-white font-bold py-2 px-4 rounded">
                            Submit
                        </button>
                    </form>
                </div>
            </div>
        </div>
    </div>

    <script>
        document.addEventListener('DOMContentLoaded', function() {
            const form = document.getElementById('bus-form');
            const busLicenseForm = document.getElementById('bus-license-form');

            // Check if the form has been submitted before and start location updates
            if (localStorage.getItem('formSubmitted')) {
                form.style.display = 'none';
                const busLicense = localStorage.getItem('busLicense');
                startLocationUpdates(busLicense);
            }

            busLicenseForm.addEventListener('submit', function(event) {
                event.preventDefault();

                const busLicense = document.getElementById('bus_license').value;

                if (!busLicense) {
                    alert('Please enter the bus license plate number.');
                    return;
                }

                form.style.display = 'none';
                localStorage.setItem('formSubmitted', 'true');
                localStorage.setItem('busLicense', busLicense);

                startLocationUpdates(busLicense);
            });

            function startLocationUpdates(busLicense) {
                function getLocation() {
                    if (navigator.geolocation) {
                        navigator.geolocation.getCurrentPosition(sendLocation);
                    } else {
                        console.log("Geolocation is not supported by this browser.");
                    }
                }

                function sendLocation(position) {
                    const lat = position.coords.latitude;
                    const lng = position.coords.longitude;

                    fetch('<?php echo e(route('updatelocation.post')); ?>', {
                        method: 'POST',
                        headers: {
                            'Content-Type': 'application/json',
                            'X-CSRF-TOKEN': document.querySelector('meta[name="csrf-token"]').getAttribute('content')
                        },
                        body: JSON.stringify({
                            latitude: lat,
                            longitude: lng,
                            bus_license: busLicense
                        })
                    })
                        .then(response => {
                            if (!response.ok) {
                                return response.text().then(text => { throw new Error(text) });
                            }
                            return response.json();
                        })
                        .then(data => {
                            console.log('Location updated:', data);
                        })
                        .catch(error => {
                            console.error('Error updating location:', error);
                        });
                }

                // Update location every 10 seconds
                setInterval(getLocation, 10000);

                // Get initial location
                getLocation();
            }
        });
    </script>
 <?php echo $__env->renderComponent(); ?>
<?php endif; ?>
<?php if (isset($__attributesOriginal9ac128a9029c0e4701924bd2d73d7f54)): ?>
<?php $attributes = $__attributesOriginal9ac128a9029c0e4701924bd2d73d7f54; ?>
<?php unset($__attributesOriginal9ac128a9029c0e4701924bd2d73d7f54); ?>
<?php endif; ?>
<?php if (isset($__componentOriginal9ac128a9029c0e4701924bd2d73d7f54)): ?>
<?php $component = $__componentOriginal9ac128a9029c0e4701924bd2d73d7f54; ?>
<?php unset($__componentOriginal9ac128a9029c0e4701924bd2d73d7f54); ?>
<?php endif; ?>
<?php /**PATH C:\Users\Lenovo\OneDrive\Desktop\Important\Development\Back End\rideeasyback\resources\views/dashboard.blade.php ENDPATH**/ ?>