<img src="{{asset('/images/pngtree-high-detailed-bus-vector-png-image_6172563.png ')}}" width="100" height="100" alt="Logo">
